// PLACEHOLDER — this file is overwritten by `python training/convert.py`
// once you have trained on real data. Do not hand-edit; it's regenerated.
#ifndef NAAD_MODEL_DATA_H_
#define NAAD_MODEL_DATA_H_

extern const unsigned char g_naad_kws_model_data[];
extern const unsigned int g_naad_kws_model_data_len;

#endif  // NAAD_MODEL_DATA_H_
