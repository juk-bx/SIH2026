// PLACEHOLDER model — this is NOT a trained model. It exists only so the
// firmware compiles before you've run the training pipeline.
// Run `python training/train.py && python training/convert.py` from the
// project root; that regenerates this file with your real int8 model.
#include "model_data.h"

alignas(16) const unsigned char g_naad_kws_model_data[] = {
  0x00
};

const unsigned int g_naad_kws_model_data_len = 0;  // 0 = "no real model yet"
